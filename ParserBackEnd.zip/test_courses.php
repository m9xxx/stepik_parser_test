<?php
// Абсолютный путь к вашему vendor/autoload.php
require_once __DIR__ . '/vendor/autoload.php';
use App\Services\CourseService;
use App\Services\ParserService;
// Тестирование работы с курсами
function testCourseService() {
echo "===== Тестирование CourseService =====\n";
$courseService = new CourseService();

// Получаем все курсы
echo "1. Получение всех курсов:\n";
$allCourses = $courseService->getAllCourses();
echo "Всего курсов: " . count($allCourses) . "\n\n";

// Вывод первых 5 курсов
echo "Первые 5 курсов:\n";
foreach (array_slice($allCourses, 0, 5) as $course) {
    echo "ID: {$course['id']}, Название: {$course['title']}, Источник: {$course['source']}\n";
}

// Поиск курсов
echo "\n2. Поиск курсов по запросу 'python':\n";
$pythonCourses = $courseService->searchCourses('python');
echo "Найдено курсов: " . count($pythonCourses) . "\n";
foreach ($pythonCourses as $course) {
    echo "ID: {$course['id']}, Название: {$course['title']}, Источник: {$course['source']}\n";
}

// Получение конкретного курса
echo "\n3. Получение курса по ID:\n";
$course = $courseService->getCourseById('stepik', 67);
if ($course) {
    echo "Курс найден: {$course['title']} (Источник: {$course['source']})\n";
} else {
    echo "Курс не найден\n";
}
}
// Тестирование работы парсеров
function testParserService() {
echo "\n===== Тестирование ParserService =====\n";
$parserService = new ParserService();

// Получение статистики парсеров
echo "1. Статистика парсеров:\n";
$statistics = $parserService->getParserStatistics();

foreach ($statistics as $parserName => $stats) {
    echo "Парсер: {$parserName}\n";
    foreach ($stats as $key => $value) {
        echo "  {$key}: {$value}\n";
    }
    echo "\n";
}
}
// Запуск тестов
function runTests() {
try {
testCourseService();
testParserService();
} catch (Exception $e) {
echo "Ошибка при выполнении тестов: " . $e->getMessage() . "\n";
echo "Трассировка: " . $e->getTraceAsString() . "\n";
}
}
// Выполнение тестов
runTests();