<?php
use App\Controllers\CourseController;
use App\Controllers\ParserController;
$requestUri = $_SERVER['REQUEST_URI'];
$method = $_SERVER['REQUEST_METHOD'];
$courseController = new CourseController();
$parserController = new ParserController();
// Роутинг для курсов
if ($method === 'GET') {
switch (true) {
case preg_match('/^/api/courses$/', $requestUri):
$courseController->index();
break;
    case preg_match('/^\/api\/courses\/search$/', $requestUri):
        $courseController->search();
        break;
    
    case preg_match('/^\/api\/courses\/([a-z]+)\/(\d+)$/', $requestUri, $matches):
        $courseController->show($matches[1], $matches[2]);
        break;
}
}
// Роутинг для парсеров
if ($method === 'POST') {
switch (true) {
case $requestUri === '/api/parsers/run':
$parserController->runParsers();
break;
}
}