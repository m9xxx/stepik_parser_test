<?php
namespace App\Controllers;
use App\Services\ParserService;
class ParserController {
private $parserService;
public function __construct() {
    $this->parserService = new ParserService();
}

public function runAllParsers() {
    try {
        $results = $this->parserService->runAllParsers();
        $this->jsonResponse($results);
    } catch (\Exception $e) {
        $this->jsonResponse(['error' => $e->getMessage()], 500);
    }
}

public function runSpecificParser($parserName) {
    try {
        $result = $this->parserService->runSpecificParser($parserName);
        $this->jsonResponse($result);
    } catch (\Exception $e) {
        $this->jsonResponse(['error' => $e->getMessage()], 400);
    }
}

public function getParserStatistics() {
    try {
        $statistics = $this->parserService->getParserStatistics();
        $this->jsonResponse($statistics);
    } catch (\Exception $e) {
        $this->jsonResponse(['error' => $e->getMessage()], 500);
    }
}

private function jsonResponse($data, $status = 200) {
    header('Content-Type: application/json');
    http_response_code($status);
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}
}