<?php
namespace App\Controllers;

use App\Services\CourseService;
use App\Utils\JsonDataReader;

class CourseController {
    private $courseService;

    public function __construct() {
        $this->courseService = new CourseService(new JsonDataReader());
    }

    public function index() {
        $courses = $this->courseService->getAllCourses();
        return $this->jsonResponse(
            array_map(function($course) { return $course->toArray(); }, $courses)
        );
    }

    public function show($source, $id) {
        $course = $this->courseService->getCourseById($id, $source);
        
        if (!$course) {
            return $this->jsonResponse(['error' => 'Курс не найден'], 404);
        }

        return $this->jsonResponse($course->toArray());
    }

    public function search() {
        $query = $_GET['query'] ?? '';
        $filters = [
            'source' => $_GET['source'] ?? null,
            'rating' => $_GET['rating'] ?? null
        ];

        $courses = $this->courseService->searchCourses($query, array_filter($filters));

        return $this->jsonResponse(
            array_map(function($course) { return $course->toArray(); }, $courses)
        );
    }

    private function jsonResponse($data, $statusCode = 200) {
        header('Content-Type: application/json');
        http_response_code($statusCode);
        echo json_encode($data, JSON_UNESCAPED_UNICODE);
        exit;
    }
}

class ParserController {
    public function runParsers() {
        $stepikParserPath = dirname(__DIR__, 2) . '/stepik_stableParser.php';
        $skillboxParserPath = dirname(__DIR__, 2) . '/skillboxParser.php';

        $stepikOutput = shell_exec("php $stepikParserPath 2>&1");
        $skillboxOutput = shell_exec("php $skillboxParserPath 2>&1");

        return $this->jsonResponse([
            'stepik_parser' => $stepikOutput,
            'skillbox_parser' => $skillboxOutput
        ]);
    }

    private function jsonResponse($data, $statusCode = 200) {
        header('Content-Type: application/json');
        http_response_code($statusCode);
        echo json_encode($data, JSON_UNESCAPED_UNICODE);
        exit;
    }
}