<?php
namespace App\Models;

class Course {
    private $id;
    private $title;
    private $description;
    private $rating;
    private $url;
    private $source;
    private $additionalData;

    public function __construct($data, $source) {
        $this->id = $data['id'] ?? null;
        $this->title = $data['title'] ?? null;
        $this->description = $data['description'] ?? null;
        $this->rating = $data['rating'] ?? null;
        $this->url = $data['url'] ?? null;
        $this->source = $source;
        $this->additionalData = $data;
    }

    public function toArray() {
        return [
            'id' => $this->id,
            'title' => $this->title,
            'description' => $this->description,
            'rating' => $this->rating,
            'url' => $this->url,
            'source' => $this->source,
            'additional_data' => $this->additionalData
        ];
    }

    // Геттеры
    public function getId() { return $this->id; }
    public function getTitle() { return $this->title; }
    public function getDescription() { return $this->description; }
    public function getRating() { return $this->rating; }
    public function getUrl() { return $this->url; }
    public function getSource() { return $this->source; }
}