<?php
namespace App\Services;
use App\Utils\JsonDataReader;
use App\Models\Course;
class CourseService {
private $jsonDataReader;
public function __construct(JsonDataReader $jsonDataReader) {
    $this->jsonDataReader = $jsonDataReader;
}

public function getAllCourses() {
    $stepikCourses = $this->jsonDataReader->readStepikCourses();
    $skillboxCourses = $this->jsonDataReader->readSkillboxCourses();

    $courses = [];
    foreach ($stepikCourses as $courseData) {
        $courses[] = new Course($courseData, 'stepik');
    }
    foreach ($skillboxCourses as $courseData) {
        $courses[] = new Course($courseData, 'skillbox');
    }

    return $courses;
}

public function getCourseById($id, $source) {
    $courses = $source === 'stepik' 
        ? $this->jsonDataReader->readStepikCourses() 
        : $this->jsonDataReader->readSkillboxCourses();

    $filteredCourses = $this->jsonDataReader->filterCourses($courses, [
        'id' => $id
    ]);

    if (empty($filteredCourses)) {
        return null;
    }

    $courseData = reset($filteredCourses);
    return new Course($courseData, $source);
}

public function searchCourses($query, $filters = []) {
    $courses = $this->getAllCourses();

    return array_filter($courses, function($course) use ($query, $filters) {
        $matchesQuery = empty($query) || 
            stripos($course->getTitle(), $query) !== false || 
            stripos($course->getDescription(), $query) !== false;

        $matchesFilters = true;
        foreach ($filters as $key => $value) {
            $methodName = 'get' . ucfirst($key);
            if (method_exists($course, $methodName)) {
                if ($course->$methodName() != $value) {
                    $matchesFilters = false;
                    break;
                }
            }
        }

        return $matchesQuery && $matchesFilters;
    });
}
}