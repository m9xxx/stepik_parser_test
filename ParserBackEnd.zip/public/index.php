<?php
require_once dirname(__DIR__) . '/vendor/autoload.php';

// Настройки CORS
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Обработка preflight-запросов
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// Подключаем роутер
require_once dirname(__DIR__) . '/routes/api.php';